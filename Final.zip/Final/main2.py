import cv2
import pytesseract
import streamlit as st
import pandas as pd
import numpy as np
from PIL import Image
import os
import base64


pytesseract.pytesseract.tesseract_cmd = 'C:\\Program Files\\Tesseract-OCR\\tesseract.exe'

cascade= cv2.CascadeClassifier("haarcascade_russian_plate_number.xml")
# Load the CSV file containing car information
car_data = pd.read_csv('car_data.csv')
upload_path = "uploads/"
download_path = "downloads/"
# Function to extract license plate numbers from an image
def extract_num(img_name):
    img = cv2.imread(img_name) ## Reading Image
    # Converting into Gray
    gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    # Detecting plate
    nplate = cascade.detectMultiScale(gray,1.1,4)
    for (x,y,w,h) in nplate:
        # Crop a portion of plate
        a,b = (int(0.02*img.shape[0]), int(0.025*img.shape[1]))
        plate = img[y+a:y+h-a, x+b:x+w-b, :]
        # make image more darker to identify the LPR
        ## iMAGE PROCESSING
        kernel = np.ones((1, 1), np.uint8)
        plate = cv2.dilate(plate, kernel, iterations=1)
        plate = cv2.erode(plate, kernel, iterations=1)
        plate_gray = cv2.cvtColor(plate,cv2.COLOR_BGR2GRAY)
        (thresh, plate) = cv2.threshold(plate_gray, 127, 255, cv2.THRESH_BINARY)
        # Feed Image to OCR engine
        read = pytesseract.image_to_string(plate)
        read = ''.join(e for e in read if e.isalnum())
        # print(read)
        # stat = read[0:2]
        # try:
        # Fetch the State information
        #     print('Car Belongs to',states[stat])
        # except:
        #     print('State not recognised!!')
        # print(read)
        cv2.rectangle(img, (x,y), (x+w, y+h), (51,51,255), 2)
        cv2.rectangle(img, (x, y - 40), (x + w, y),(51,51,255) , -1)
        cv2.putText(img,read, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        # cv2.imshow('PLate',plate)
        # Save & display result image

    cv2.waitKey(0)
    cv2.destroyAllWindows()
    return plate,read

@st.cache(persist=True,allow_output_mutation=True,show_spinner=False,suppress_st_warning=True)
def download_success():
    st.balloons()
    st.success('✅ Download Successful !!')


def main():
    background_image = 'background.jpeg'
    page_bg = base64.b64encode(open(background_image, 'rb').read()).decode()

    st.markdown(
        f"""
        <style>
        .reportview-container {{
            background: url('data:image/jpeg;base64,{page_bg}') fixed;
            background-size: cover;
        }}
        </style>
        """,
        unsafe_allow_html=True
    )

    top_image = Image.open('background.jpeg')
    bottom_image = Image.open('Bg2.jpeg')
    main_image = Image.open('static/main_banner.png')

    st.image(main_image, use_column_width='auto')
    st.title(' Automatic Number Plate Recognition 🚘🚙')
    st.sidebar.image(top_image, use_column_width='auto')
    st.sidebar.header('Input 🛠')
    selected_type = st.sidebar.selectbox('Please select an activity type 🚀', ["Upload Image", "Live Video Feed"])
    st.sidebar.image(bottom_image, use_column_width='auto')
    
    if selected_type == "Upload Image":
        
      
        # Page 1: Login Page
        st.title("License Plate Detection System")
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        if st.button("Login"):
            # Authenticate the user and move to the next page
            if username == "admin" and password == "password":
                st.experimental_rerun()
            else:
                st.error("Invalid credentials!")
        
        # Page 2: License Plate Detection
        if username == "admin" and password == "password":
            st.title("License Plate Detection")
            st.info('✨ Supports all popular image formats 📷 - PNG, JPG, BMP 😉')
            uploaded_file = st.file_uploader("Upload Image of car's number plate 🚓", type=["png", "jpg", "bmp", "jpeg"])

            if uploaded_file is not None:
                with open(os.path.join(upload_path, uploaded_file.name), "wb") as f:
                    f.write(uploaded_file.getbuffer())
                with st.spinner(f"Working... 💫"):
                    uploaded_image = os.path.abspath(os.path.join(upload_path, uploaded_file.name))
                    # downloaded_image = os.path.abspath(os.path.join(download_path, str("output_" + uploaded_file.name)))

                    result, plate = extract_num(uploaded_image)  # Call the license plate detection function

                    # final_image = Image.open(result)
                    st.markdown("---")
                    st.write("Detected Plate Number:", plate)
                    st.image(result, caption='This is how your final image looks like 😉')

                st.success('✅ License plate detection completed!')


        if username == "admin" and password == "password":
            st.title("Car Information Search")
            
            # Display a search bar to enter the license plate number
            search_input = st.text_input("Enter License Plate Number") 
            
            if search_input:
                # Search for the entered license plate number in the car data
                search_result = car_data.loc[car_data['License Plate Number'] == search_input]
                
                if len(search_result) > 0:
                    # Display the car information
                    st.subheader("Car Information:")
                    st.write("License Plate Number:", search_result['License Plate Number'].values[0])
                    st.write("Car Model:", search_result['Car Model'].values[0])
                    st.write("Registration Year:", search_result['Registration Year'].values[0])
                    st.write("Car Color:", search_result['Car Color'].values[0])
                    st.write("Country of Origin:", search_result['Country of Origin'].values[0])
                else:
                    st.error("No car information found for the entered license plate number.")
            
            # Display random car information from the dataset
            st.subheader("Random Car Information:")
            random_car = car_data.sample()
            st.write("License Plate Number:", random_car['License Plate Number'].values[0])
            st.write("Car Model:", random_car['Car Model'].values[0])
            st.write("Registration Year:", random_car['Registration Year'].values[0])
            st.write("Car Color:", random_car['Car Color'].values[0])
            st.write("Country of Origin:", random_car['Country of Origin'].values[0])
    else: 
        # Page 1: Login Page
        st.title("License Plate Detection System")
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        if st.button("Login"):
            # Authenticate the user and move to the next page
            if username == "admin" and password == "password":
                st.experimental_rerun()
            else:
                st.error("Invalid credentials!")
        
        # Page 2: License Plate Detection
        if username == "admin" and password == "password":
            st.title("License Plate Detection")
            st.info('✨ The Live Feed from Web-Camera will take some time to load up 🎦')
            live_feed = st.checkbox('Start Web-Camera ✅')
            plate_container = st.empty()
            number_container = st.empty()
            FRAME_WINDOW = st.empty()
            cap = cv2.VideoCapture(0)

            if live_feed:
                while(cap.isOpened()):
                    success, frame = cap.read()
                    if success == True:
                        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                        plates = cascade.detectMultiScale(gray, 1.1, 4)
                
                        for (x, y, w, h) in plates:
                            a,b = (int(0.02*frame.shape[0]), int(0.025*frame.shape[1]))
                            plate = frame[y+a:y+h-a, x+b:x+w-b, :]
                            # make image more darker to identify the LPR
                            ## iMAGE PROCESSING
                            # kernel = np.ones((1, 1), np.uint8)
                            # plate = cv2.dilate(plate, kernel, iterations=1)
                            # plate = cv2.erode(plate, kernel, iterations=1)
                            # plate_gray = cv2.cvtColor(plate,cv2.COLOR_BGR2GRAY)
                            plate = cv2.cvtColor(plate, cv2.COLOR_BGR2GRAY)
                            # Feed Image to OCR engine
                            read = pytesseract.image_to_string(plate)
                            read = ''.join(e for e in read if e.isalnum())
                            cv2.rectangle(frame, (x,y), (x+w, y+h), (51,51,255), 2)
                            cv2.rectangle(frame, (x, y - 40), (x + w, y),(51,51,255) , -1)
                            cv2.putText(frame,read, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

                            
                            # Display the detected plate text and image in the Streamlit app
                            number_container.write("Detected Plate Number: " + read)
                            plate_container.image(plate, use_column_width=True, output_format='JPEG')
                    
                        # frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                        FRAME_WINDOW.image(frame)
                    else:
                        break
                    frame = cv2.imencode('.jpg', frame)[1].tobytes()
                    FRAME_WINDOW.image(frame)
            else:
                cap.release()
                cv2.destroyAllWindows()
                st.warning('⚠ The Web-Camera is currently disabled. 😯')

    
        # Page 3: Car Information Search
        if username == "admin" and password == "password":
            st.title("Car Information Search")
            
            # Display a search bar to enter the license plate number
            search_input = st.text_input("Enter License Plate Number")
            
            if search_input:
                # Search for the entered license plate number in the car data
                search_result = car_data.loc[car_data['License Plate Number'] == search_input]
                
                if len(search_result) > 0:
                    # Display the car information
                    st.subheader("Car Information:")
                    st.write("License Plate Number:", search_result['License Plate Number'].values[0])
                    st.write("Car Model:", search_result['Car Model'].values[0])
                    st.write("Registration Year:", search_result['Registration Year'].values[0])
                    st.write("Car Color:", search_result['Car Color'].values[0])
                    st.write("Country of Origin:", search_result['Country of Origin'].values[0])
                else:
                    st.error("No car information found for the entered license plate number.")
            
            # Display random car information from the dataset
            st.subheader("Random Car Information:")
            random_car = car_data.sample()
            st.write("License Plate Number:", random_car['License Plate Number'].values[0])
            st.write("Car Model:", random_car['Car Model'].values[0])
            st.write("Registration Year:", random_car['Registration Year'].values[0])
            st.write("Car Color:", random_car['Car Color'].values[0])
            st.write("Country of Origin:", random_car['Country of Origin'].values[0])

# Run the Streamlit application
if __name__ == "__main__":
    
    main()